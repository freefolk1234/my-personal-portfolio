import 'package:get/get.dart';

import '../../view_models/view_models.dart';

class AuthController extends GetxController {
  AuthController(this._viewModel);

  final AuthViewModel _viewModel;
}
