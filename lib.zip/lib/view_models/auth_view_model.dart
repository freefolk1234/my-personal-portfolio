import '../repositories/repositories.dart';

class AuthViewModel {
  const AuthViewModel(this._repository);

  final AuthRepository _repository;
}
