class AuthRepository {}
