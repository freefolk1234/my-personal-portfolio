class ConfigConstants {
  const ConfigConstants._();

  static const String devServerUrl = '';

  static const String devUsername = '';

  static const String devPassword = '';

  static const int devPort = 0;

  static const String devOneSignalId = '';
}
