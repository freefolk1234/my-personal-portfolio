class LocalKeys {
  const LocalKeys._();
  static const authToken = 'authToken';
  static const refreshToken = 'refreshToken';
}
