import 'package:flutter/material.dart';

class ColorsValue {
  const ColorsValue._();

  static const Color primaryColor = Colors.purple;
}
