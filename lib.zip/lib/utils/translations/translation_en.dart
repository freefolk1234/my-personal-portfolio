part of 'translation_values.dart';

var en = <String, String>{
  TranslationKeys.appName: 'Prosens',
};
