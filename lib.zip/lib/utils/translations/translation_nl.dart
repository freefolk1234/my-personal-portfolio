part of 'translation_values.dart';

var nl = <String, String>{
  TranslationKeys.appName: 'Prosens',
};
